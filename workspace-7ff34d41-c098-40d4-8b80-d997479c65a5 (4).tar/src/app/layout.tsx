import type { Metadata, Viewport } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import { Toaster } from "sonner";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-cairo",
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  display: "swap",
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#059669",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "مكه استور",
  },
};

export const metadata: Metadata = {
  title: "مكه استور | أدوات مدرسية - بنها مينة السباع",
  description:
    "مكه استور - أكبر معرض لأدوات المدارس في بنها مينة السباع - القليوبية. أقلام، دفاتر، حقائب، أدوات هندسية، ألوان وباقات مدرسية.",
  manifest: "/manifest.json",
  icons: {
    icon: [
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-192x192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512x512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: "/apple-touch-icon.png",
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "مكه استور",
  },
  other: {
    "mobile-web-app-capable": "yes",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <link rel="manifest" href="/manifest.json" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="مكه استور" />
      </head>
      <body className={`${cairo.variable} antialiased bg-background text-foreground`}
        style={{ fontFamily: "var(--font-cairo), 'Cairo', 'Segoe UI', Tahoma, sans-serif" }}>
        {children}
        <Toaster position="top-center" richColors dir="rtl" />
        <PWARegister />
      </body>
    </html>
  );
}

// Service Worker Registration (client component would need separate file, inline script for layout)
function PWARegister() {
  return (
    <script
      dangerouslySetInnerHTML={{
        __html: `
          if ('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
              navigator.serviceWorker.register('/sw.js')
                .then(function(reg) {
                  console.log('SW registered:', reg.scope);
                })
                .catch(function(err) {
                  console.log('SW registration failed:', err);
                });
            });
          }
        `,
      }}
    />
  );
}