'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

// PWA type
declare global {
  interface WindowEventMap {
    beforeinstallprompt: BeforeInstallPromptEvent
  }
  interface BeforeInstallPromptEvent extends Event {
    prompt(): Promise<void>
    userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>
  }
}
import {
  ShoppingCart, Search, Star, Phone, MapPin, Clock, Facebook, MessageCircle,
  Settings, Package, Plus, Pencil, Trash2, X, Save, ArrowUpDown,
  Grid3X3, Tag, Store, LogOut, ShieldCheck,
  Percent, Menu, X as XIcon, ChevronUp, Download
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import { Textarea } from '@/components/ui/textarea'

// ==================== TYPES ====================
interface Category {
  id: string
  name: string
  nameEn?: string | null
  icon?: string | null
  order: number
  active: boolean
  _count: { products: number }
}

interface Product {
  id: string
  name: string
  description?: string | null
  price: number
  oldPrice?: number | null
  categoryId: string
  image?: string | null
  inStock: boolean
  featured: boolean
  order: number
  category?: Category
}

interface StoreSettings {
  id: string
  storeName: string
  phone?: string | null
  address?: string | null
  whatsapp?: string | null
  facebook?: string | null
}

// ==================== ADMIN PASSWORD ====================
const ADMIN_PASSWORD = 'makka2024'

// ==================== COLOR PALETTE FOR CATEGORIES ====================
const CATEGORY_COLORS = [
  'bg-emerald-100 text-emerald-800 border-emerald-200',
  'bg-amber-100 text-amber-800 border-amber-200',
  'bg-rose-100 text-rose-800 border-rose-200',
  'bg-sky-100 text-sky-800 border-sky-200',
  'bg-violet-100 text-violet-800 border-violet-200',
  'bg-orange-100 text-orange-800 border-orange-200',
  'bg-teal-100 text-teal-800 border-teal-200',
  'bg-pink-100 text-pink-800 border-pink-200',
]

// ==================== MAIN PAGE ====================
export default function Home() {
  const [view, setView] = useState<'store' | 'admin'>('store')
  const [isAdmin, setIsAdmin] = useState(false)
  const [adminPassword, setAdminPassword] = useState('')
  const [showLogin, setShowLogin] = useState(false)
  const [mobileMenu, setMobileMenu] = useState(false)

  // Store data
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [settings, setSettings] = useState<StoreSettings | null>(null)
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc' | 'name'>('default')
  const [showFeaturedOnly, setShowFeaturedOnly] = useState(false)

  // Loading
  const [loading, setLoading] = useState(true)
  const [seeded, setSeeded] = useState(false)

  // PWA Install
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showInstallBanner, setShowInstallBanner] = useState(false)

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault()
      setInstallPrompt(e as BeforeInstallPromptEvent)
      setShowInstallBanner(true)
    }
    window.addEventListener('beforeinstallprompt', handler)
    return () => window.removeEventListener('beforeinstallprompt', handler)
  }, [])

  const handleInstall = async () => {
    if (!installPrompt) return
    await installPrompt.prompt()
    const result = await installPrompt.userChoice
    if (result.outcome === 'accepted') {
      toast.success('تم تثبيت التطبيق بنجاح!')
    }
    setInstallPrompt(null)
    setShowInstallBanner(false)
  }

  const fetchData = useCallback(async () => {
    try {
      const [productsRes, categoriesRes, settingsRes] = await Promise.all([
        fetch('/api/products?categoryId=' + (showFeaturedOnly ? '' : selectedCategory) + (showFeaturedOnly ? '&featured=true' : '') + (searchQuery ? '&search=' + encodeURIComponent(searchQuery) : '')),
        fetch('/api/categories'),
        fetch('/api/settings'),
      ])
      const productsData = await productsRes.json()
      const categoriesData = await categoriesRes.json()
      const settingsData = await settingsRes.json()
      setProducts(Array.isArray(productsData) ? productsData : [])
      setCategories(Array.isArray(categoriesData) ? categoriesData : [])
      setSettings(settingsData)
    } catch (error) {
      console.error('Fetch error:', error)
    } finally {
      setLoading(false)
    }
  }, [selectedCategory, searchQuery, showFeaturedOnly])

  const seedDatabase = async () => {
    try {
      await fetch('/api/seed', { method: 'POST' })
      setSeeded(true)
      toast.success('تم تحميل المنتجات بنجاح!')
      fetchData()
    } catch {
      toast.error('حدث خطأ أثناء تحميل المنتجات')
    }
  }

  useEffect(() => {
    seedDatabase()
  }, [])

  useEffect(() => {
    if (seeded) fetchData()
  }, [fetchData, seeded])

  // Sorting
  const sortedProducts = [...products].sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price
    if (sortBy === 'price-desc') return b.price - a.price
    if (sortBy === 'name') return a.name.localeCompare(b.name, 'ar')
    return a.order - b.order
  })

  // Login handler
  const handleLogin = () => {
    if (adminPassword === ADMIN_PASSWORD) {
      setIsAdmin(true)
      setShowLogin(false)
      setAdminPassword('')
      toast.success('تم تسجيل الدخول بنجاح')
    } else {
      toast.error('كلمة المرور غير صحيحة')
    }
  }

  // ==================== RENDER ====================
  return (
    <div className="min-h-screen flex flex-col" style={{ fontFamily: "'Cairo', 'Segoe UI', Tahoma, sans-serif" }}>
      {/* ===== HEADER ===== */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-emerald-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          {/* Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-emerald-700 rounded-xl flex items-center justify-center shadow-lg">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-emerald-800 leading-tight">{settings?.storeName || 'مكه استور'}</h1>
              <p className="text-[10px] text-muted-foreground leading-tight">أدوات مدرسية - بنها مينة السباع</p>
            </div>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-2">
            <Button variant={view === 'store' ? 'default' : 'ghost'} size="sm"
              className={view === 'store' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              onClick={() => setView('store')}>
              <Store className="w-4 h-4 ml-1" /> المتجر
            </Button>
            {isAdmin && (
              <Button variant={view === 'admin' ? 'default' : 'ghost'} size="sm"
                className={view === 'admin' ? 'bg-amber-600 hover:bg-amber-700' : ''}
                onClick={() => setView('admin')}>
                <Settings className="w-4 h-4 ml-1" /> لوحة التحكم
              </Button>
            )}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {isAdmin ? (
              <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-700 hover:bg-red-50"
                onClick={() => { setIsAdmin(false); setView('store') }}>
                <LogOut className="w-4 h-4 ml-1" /> خروج
              </Button>
            ) : (
              <Button variant="ghost" size="sm" className="text-emerald-700 hover:bg-emerald-50"
                onClick={() => setShowLogin(true)}>
                <ShieldCheck className="w-4 h-4 ml-1" /> المدير
              </Button>
            )}
            <Button variant="ghost" size="sm" className="md:hidden" onClick={() => setMobileMenu(!mobileMenu)}>
              {mobileMenu ? <XIcon className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenu && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden overflow-hidden border-t border-emerald-50"
            >
              <div className="px-4 py-3 space-y-2">
                <Button variant={view === 'store' ? 'default' : 'ghost'} size="sm" className="w-full justify-start"
                  onClick={() => { setView('store'); setMobileMenu(false) }}>
                  <Store className="w-4 h-4 ml-2" /> المتجر
                </Button>
                {isAdmin && (
                  <Button variant={view === 'admin' ? 'default' : 'ghost'} size="sm" className="w-full justify-start"
                    onClick={() => { setView('admin'); setMobileMenu(false) }}>
                    <Settings className="w-4 h-4 ml-2" /> لوحة التحكم
                  </Button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* ===== MAIN CONTENT ===== */}
      <main className="flex-1">
        {view === 'store' ? (
          <StoreView
            products={sortedProducts}
            categories={categories}
            settings={settings}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            sortBy={sortBy}
            setSortBy={setSortBy}
            showFeaturedOnly={showFeaturedOnly}
            setShowFeaturedOnly={setShowFeaturedOnly}
            loading={loading}
          />
        ) : isAdmin ? (
          <AdminPanel
            categories={categories}
            onRefresh={fetchData}
          />
        ) : null}
      </main>

      {/* ===== FOOTER ===== */}
      <footer className="bg-emerald-800 text-white mt-auto">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                  <Store className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold">{settings?.storeName || 'مكه استور'}</h3>
              </div>
              <p className="text-emerald-200 text-sm leading-relaxed">
                أكبر معرض للأدوات المدرسية في بنها. نوفر لكم أفضل المنتجات بأفضل الأسعار.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-3 flex items-center gap-2">
                <MapPin className="w-4 h-4" /> معلومات التواصل
              </h4>
              <div className="space-y-2 text-emerald-200 text-sm">
                <p className="flex items-center gap-2"><MapPin className="w-4 h-4" /> {settings?.address || 'بنها - مينة السباع - القليوبية'}</p>
                <p className="flex items-center gap-2"><Phone className="w-4 h-4" /> {settings?.phone || '01012345678'}</p>
                <p className="flex items-center gap-2"><Clock className="w-4 h-4" /> يومياً من 9 صباحاً - 10 مساءً</p>
              </div>
            </div>
            <div>
              <h4 className="font-bold mb-3">تواصل معنا</h4>
              <div className="flex gap-3">
                {settings?.whatsapp && (
                  <a href={`https://wa.me/${settings.whatsapp}`} target="_blank" rel="noopener noreferrer"
                    className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center hover:bg-green-700 transition-colors">
                    <MessageCircle className="w-5 h-5" />
                  </a>
                )}
                {settings?.facebook && (
                  <a href={`https://facebook.com/${settings.facebook}`} target="_blank" rel="noopener noreferrer"
                    className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                    <Facebook className="w-5 h-5" />
                  </a>
                )}
                <a href={`tel:${settings?.phone || '01012345678'}`}
                  className="w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center hover:bg-emerald-700 transition-colors">
                  <Phone className="w-5 h-5" />
                </a>
              </div>
              <p className="text-emerald-300 text-xs mt-3">محفظة القليوبية - بنها مينة السباع</p>
            </div>
          </div>
          <Separator className="my-6 bg-emerald-700" />
          <p className="text-center text-emerald-300 text-sm">© 2024 {settings?.storeName || 'مكه استور'} - جميع الحقوق محفوظة</p>
        </div>
      </footer>

      {/* ===== LOGIN DIALOG ===== */}
      <Dialog open={showLogin} onOpenChange={setShowLogin}>
        <DialogContent className="sm:max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-center text-emerald-800">تسجيل دخول المدير</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center">
                <ShieldCheck className="w-8 h-8 text-emerald-600" />
              </div>
            </div>
            <Input
              type="password"
              placeholder="أدخل كلمة المرور"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              className="text-center text-lg"
            />
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700" onClick={handleLogin}>
              دخول
            </Button>
            <p className="text-xs text-center text-muted-foreground">كلمة السر: makka2024</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== PWA INSTALL BANNER ===== */}
      <AnimatePresence>
        {showInstallBanner && (
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-0 left-0 right-0 z-50 p-4 md:hidden"
          >
            <div className="bg-white rounded-2xl shadow-2xl border border-emerald-200 p-4 flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center shrink-0">
                <Download className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-sm text-foreground">ثبّت مكه استور على جهازك!</p>
                <p className="text-xs text-muted-foreground">يشتغل حتى بدون نت وسريع أوي</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-xs" onClick={handleInstall}>
                  تثبيت
                </Button>
                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setShowInstallBanner(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  )
}

// ==================== STORE VIEW ====================
function StoreView({
  products, categories, settings, selectedCategory, setSelectedCategory,
  searchQuery, setSearchQuery, sortBy, setSortBy,
  showFeaturedOnly, setShowFeaturedOnly, loading
}: {
  products: Product[]
  categories: Category[]
  settings: StoreSettings | null
  selectedCategory: string
  setSelectedCategory: (v: string) => void
  searchQuery: string
  setSearchQuery: (v: string) => void
  sortBy: string
  setSortBy: (v: 'default' | 'price-asc' | 'price-desc' | 'name') => void
  showFeaturedOnly: boolean
  setShowFeaturedOnly: (v: boolean) => void
  loading: boolean
}) {
  const [showScrollUp, setShowScrollUp] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollUp(window.scrollY > 400)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' })

  return (
    <div>
      {/* ===== HERO BANNER ===== */}
      <section className="relative bg-gradient-to-bl from-emerald-700 via-emerald-600 to-emerald-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-10 w-40 h-40 border-2 border-white rounded-full" />
          <div className="absolute bottom-10 left-10 w-60 h-60 border border-white rounded-full" />
          <div className="absolute top-1/2 left-1/3 w-32 h-32 border border-white rounded-full" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 py-16 md:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl"
          >
            <Badge className="bg-amber-500 text-white border-amber-400 mb-4 px-4 py-1 text-sm">
              <Star className="w-3 h-3 ml-1" /> العرض الجديد
            </Badge>
            <h2 className="text-3xl md:text-5xl font-extrabold mb-4 leading-tight">
              كل أدواتك المدرسية<br />
              <span className="text-amber-300">في مكان واحد</span>
            </h2>
            <p className="text-emerald-100 text-lg mb-8 leading-relaxed">
              مرحباً بكم في {settings?.storeName || 'مكه استور'} — أكبر معرض أدوات مدرسية في محفظة القليوبية. بنها مينة السباع.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-white font-bold"
                onClick={() => document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' })}>
                <ShoppingCart className="w-5 h-5 ml-2" /> تصفح المنتجات
              </Button>
              <Button size="lg" variant="outline" className="border-white/40 text-white hover:bg-white/10"
                onClick={() => { if (settings?.phone) window.open(`tel:${settings.phone}`) }}>
                <Phone className="w-5 h-5 ml-2" /> اتصل بنا
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ===== STATS BAR ===== */}
      <section className="bg-white border-b border-emerald-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-emerald-700">{categories.length}+</p>
              <p className="text-xs text-muted-foreground">تصنيف</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-emerald-700">{products.length}+</p>
              <p className="text-xs text-muted-foreground">منتج</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-amber-600">أفضل الأسعار</p>
              <p className="text-xs text-muted-foreground">في القليوبية</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-emerald-700">توصيل سريع</p>
              <p className="text-xs text-muted-foreground">داخل بنها</p>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FILTERS & PRODUCTS ===== */}
      <section id="products-section" className="max-w-7xl mx-auto px-4 py-8">
        {/* Search & Filter Bar */}
        <div className="bg-white rounded-2xl shadow-sm border border-emerald-50 p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-3">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="ابحث عن منتج..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 h-11"
              />
            </div>
            {/* Sort */}
            <Select value={sortBy} onValueChange={(v) => setSortBy(v as typeof sortBy)}>
              <SelectTrigger className="h-11 w-full md:w-48">
                <ArrowUpDown className="w-4 h-4 ml-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">الترتيب الافتراضي</SelectItem>
                <SelectItem value="price-asc">السعر: الأقل أولاً</SelectItem>
                <SelectItem value="price-desc">السعر: الأعلى أولاً</SelectItem>
                <SelectItem value="name">الاسم</SelectItem>
              </SelectContent>
            </Select>
            {/* Featured toggle */}
            <Button
              variant={showFeaturedOnly ? 'default' : 'outline'}
              size="default"
              className={`h-11 ${showFeaturedOnly ? 'bg-amber-500 hover:bg-amber-600' : 'border-amber-300 text-amber-700'}`}
              onClick={() => setShowFeaturedOnly(!showFeaturedOnly)}
            >
              <Star className={`w-4 h-4 ml-1 ${showFeaturedOnly ? 'fill-white' : ''}`} />
              {showFeaturedOnly ? 'عرض الكل' : 'المميزة فقط'}
            </Button>
          </div>
        </div>

        {/* Category Chips */}
        {!showFeaturedOnly && (
          <div className="flex flex-wrap gap-2 mb-6">
            <Button
              key="all"
              variant={selectedCategory === 'all' ? 'default' : 'outline'}
              size="sm"
              className={selectedCategory === 'all' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}
              onClick={() => setSelectedCategory('all')}
            >
              <Grid3X3 className="w-4 h-4 ml-1" /> الكل
            </Button>
            {categories.map((cat, i) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.id ? 'default' : 'outline'}
                size="sm"
                className={selectedCategory === cat.id
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : CATEGORY_COLORS[i % CATEGORY_COLORS.length]}
                onClick={() => setSelectedCategory(cat.id)}
              >
                <span>{cat.icon}</span>
                <span className="mr-1">{cat.name}</span>
                <Badge variant="secondary" className="mr-1 text-[10px] h-5 px-1.5">
                  {cat._count.products}
                </Badge>
              </Button>
            ))}
          </div>
        )}

        {/* Products Grid */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <div className="aspect-square bg-muted animate-pulse" />
                <CardContent className="p-4 space-y-2">
                  <div className="h-4 bg-muted rounded animate-pulse" />
                  <div className="h-6 bg-muted rounded animate-pulse w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-lg text-muted-foreground">لا توجد منتجات في هذا التصنيف</p>
          </div>
        ) : (
          <motion.div
            layout
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"
          >
            {products.map((product, i) => (
              <ProductCard key={product.id} product={product} index={i} />
            ))}
          </motion.div>
        )}
      </section>

      {/* Scroll to top button */}
      <AnimatePresence>
        {showScrollUp && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed bottom-6 left-6 z-40 w-12 h-12 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full shadow-lg flex items-center justify-center transition-colors"
            onClick={scrollToTop}
          >
            <ChevronUp className="w-6 h-6" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  )
}

// ==================== PRODUCT CARD ====================
function ProductCard({ product, index }: { product: Product; index: number }) {
  const discount = product.oldPrice ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) : 0
  const catIndex = product.category ? categories_order.indexOf(product.category.id) : 0

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: Math.min(index * 0.05, 0.3) }}
    >
      <Card className="group overflow-hidden hover:shadow-lg transition-all duration-300 border border-emerald-50 hover:border-emerald-200 h-full flex flex-col">
        {/* Product Image Placeholder */}
        <div className={`relative aspect-square flex items-center justify-center ${
          product.featured ? 'bg-gradient-to-br from-amber-50 to-amber-100' : 'bg-gradient-to-br from-emerald-50 to-emerald-100'
        }`}>
          <span className="text-5xl opacity-60 group-hover:scale-110 transition-transform duration-300">
            {product.category?.icon || '📦'}
          </span>
          {/* Badges */}
          <div className="absolute top-2 right-2 flex flex-col gap-1">
            {discount > 0 && (
              <Badge className="bg-red-500 text-white text-[10px] px-2">
                <Percent className="w-3 h-3 ml-0.5" />-{discount}%
              </Badge>
            )}
            {product.featured && (
              <Badge className="bg-amber-500 text-white text-[10px] px-2">
                <Star className="w-3 h-3 ml-0.5" /> مميز
              </Badge>
            )}
          </div>
          {!product.inStock && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <Badge className="bg-red-600 text-white text-sm px-4 py-1">نفذت الكمية</Badge>
            </div>
          )}
        </div>
        <CardContent className="p-3 flex-1 flex flex-col">
          <h3 className="font-semibold text-sm leading-tight mb-2 line-clamp-2 text-foreground min-h-[2.5rem]">
            {product.name}
          </h3>
          {product.description && (
            <p className="text-xs text-muted-foreground line-clamp-2 mb-2 flex-1">{product.description}</p>
          )}
          <div className="flex items-end justify-between mt-auto pt-2 border-t border-emerald-50">
            <div>
              <p className="text-lg font-bold text-emerald-700">{product.price} ج.م</p>
              {product.oldPrice && (
                <p className="text-xs text-muted-foreground line-through">{product.oldPrice} ج.م</p>
              )}
            </div>
            {product.category && (
              <Badge variant="outline" className="text-[10px] border-emerald-200 text-emerald-700">
                {product.category.icon} {product.category.name}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

const categories_order = ['cat-pens', 'cat-notebooks', 'cat-bags', 'cat-geometry', 'cat-colors', 'cat-office', 'cat-calculators', 'cat-sets']

// ==================== ADMIN PANEL ====================
function AdminPanel({ categories, onRefresh }: { categories: Category[]; onRefresh: () => void }) {
  const [activeTab, setActiveTab] = useState('products')

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
          <Settings className="w-6 h-6 text-amber-700" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-foreground">لوحة التحكم</h2>
          <p className="text-sm text-muted-foreground">إدارة المنتجات والأسعار والتصنيفات</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} dir="rtl">
        <TabsList className="mb-6">
          <TabsTrigger value="products" className="gap-2">
            <Package className="w-4 h-4" /> المنتجات
          </TabsTrigger>
          <TabsTrigger value="categories" className="gap-2">
            <Tag className="w-4 h-4" /> التصنيفات
          </TabsTrigger>
          <TabsTrigger value="store-settings" className="gap-2">
            <Store className="w-4 h-4" /> إعدادات المتجر
          </TabsTrigger>
        </TabsList>

        <TabsContent value="products">
          <ProductsManager categories={categories} onRefresh={onRefresh} />
        </TabsContent>
        <TabsContent value="categories">
          <CategoriesManager onRefresh={onRefresh} />
        </TabsContent>
        <TabsContent value="store-settings">
          <StoreSettingsManager />
        </TabsContent>
      </Tabs>
    </div>
  )
}

// ==================== PRODUCTS MANAGER ====================
function ProductsManager({ categories, onRefresh }: { categories: Category[]; onRefresh: () => void }) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [filterCat, setFilterCat] = useState('all')

  const fetchProducts = async () => {
    setLoading(true)
    try {
      const url = '/api/products' + (filterCat !== 'all' ? '?categoryId=' + filterCat : '')
      const res = await fetch(url)
      const data = await res.json()
      setProducts(Array.isArray(data) ? data : [])
    } catch { toast.error('خطأ في تحميل المنتجات') }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchProducts() }, [filterCat])

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) return
    try {
      await fetch('/api/products?id=' + id, { method: 'DELETE' })
      toast.success('تم حذف المنتج')
      fetchProducts()
      onRefresh()
    } catch { toast.error('خطأ في حذف المنتج') }
  }

  const handleSave = async () => {
    setIsDialogOpen(false)
    setEditingProduct(null)
    fetchProducts()
    onRefresh()
  }

  const filtered = filterCat === 'all' ? products : products.filter(p => p.categoryId === filterCat)

  return (
    <Card>
      <CardContent className="p-4 md:p-6">
        <div className="flex flex-col sm:flex-row justify-between gap-3 mb-6">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <Package className="w-5 h-5 text-emerald-600" />
            المنتجات ({products.length})
          </h3>
          <div className="flex gap-2">
            <Select value={filterCat} onValueChange={setFilterCat}>
              <SelectTrigger className="w-40 h-9 text-sm">
                <SelectValue placeholder="تصنيف" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                {categories.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) setEditingProduct(null) }}>
              <DialogTrigger asChild>
                <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700 gap-1">
                  <Plus className="w-4 h-4" /> إضافة منتج
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
                <ProductForm product={editingProduct} categories={categories} onSave={handleSave} onCancel={() => { setIsDialogOpen(false); setEditingProduct(null) }} />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-16 bg-muted rounded-lg animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {filtered.map((product) => (
              <div key={product.id} className="flex items-center gap-3 p-3 rounded-xl border border-border hover:bg-emerald-50/50 transition-colors">
                <div className="w-12 h-12 rounded-lg bg-emerald-100 flex items-center justify-center text-2xl shrink-0">
                  {product.category?.icon || '📦'}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{product.name}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{product.category?.name}</span>
                    <span>•</span>
                    <span className="font-bold text-emerald-700">{product.price} ج.م</span>
                    {product.oldPrice && (
                      <span className="line-through">{product.oldPrice} ج.م</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {product.featured && <Star className="w-4 h-4 text-amber-500 fill-amber-500" />}
                  {!product.inStock && <Badge variant="destructive" className="text-[10px]">نفذ</Badge>}
                  <Button size="icon" variant="ghost" className="h-8 w-8"
                    onClick={() => { setEditingProduct(product); setIsDialogOpen(true) }}>
                    <Pencil className="w-4 h-4 text-emerald-600" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-8 w-8"
                    onClick={() => handleDelete(product.id)}>
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <p className="text-center text-muted-foreground py-8">لا توجد منتجات</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// ==================== PRODUCT FORM ====================
function ProductForm({ product, categories, onSave, onCancel }: {
  product: Product | null
  categories: Category[]
  onSave: () => void
  onCancel: () => void
}) {
  const [form, setForm] = useState({
    name: product?.name || '',
    description: product?.description || '',
    price: product?.price?.toString() || '',
    oldPrice: product?.oldPrice?.toString() || '',
    categoryId: product?.categoryId || '',
    featured: product?.featured || false,
    inStock: product?.inStock !== false,
    order: product?.order || 0,
  })
  const [saving, setSaving] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.price || !form.categoryId) {
      toast.error('يرجى ملء الحقول المطلوبة')
      return
    }
    setSaving(true)
    try {
      if (product) {
        await fetch('/api/products', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: product.id, ...form }),
        })
        toast.success('تم تحديث المنتج بنجاح')
      } else {
        await fetch('/api/products', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(form),
        })
        toast.success('تم إضافة المنتج بنجاح')
      }
      onSave()
    } catch {
      toast.error('حدث خطأ أثناء الحفظ')
    } finally { setSaving(false) }
  }

  return (
    <form onSubmit={handleSubmit}>
      <DialogHeader>
        <DialogTitle className="text-emerald-800">
          {product ? 'تعديل المنتج' : 'إضافة منتج جديد'}
        </DialogTitle>
      </DialogHeader>
      <div className="space-y-4 mt-4">
        <div>
          <Label>اسم المنتج *</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="مثال: قلم حبر جاف ستيدلر" className="mt-1" />
        </div>
        <div>
          <Label>الوصف</Label>
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="وصف مختصر للمنتج..." className="mt-1" rows={2} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>السعر (ج.م) *</Label>
            <Input type="number" step="0.01" value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              placeholder="0.00" className="mt-1" />
          </div>
          <div>
            <Label>السعر القديم (ج.م)</Label>
            <Input type="number" step="0.01" value={form.oldPrice}
              onChange={(e) => setForm({ ...form, oldPrice: e.target.value })}
              placeholder="0.00 (اختياري)" className="mt-1" />
          </div>
        </div>
        <div>
          <Label>التصنيف *</Label>
          <Select value={form.categoryId} onValueChange={(v) => setForm({ ...form, categoryId: v })}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="اختر التصنيف" />
            </SelectTrigger>
            <SelectContent>
              {categories.map(c => (
                <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>ترتيب العرض</Label>
            <Input type="number" value={form.order}
              onChange={(e) => setForm({ ...form, order: parseInt(e.target.value) || 0 })}
              className="mt-1" />
          </div>
          <div className="flex items-center gap-6 pt-6">
            <div className="flex items-center gap-2">
              <Switch checked={form.featured} onCheckedChange={(v) => setForm({ ...form, featured: v })} />
              <Label className="text-sm">مميز</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.inStock} onCheckedChange={(v) => setForm({ ...form, inStock: v })} />
              <Label className="text-sm">متوفر</Label>
            </div>
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <Button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-700" disabled={saving}>
            <Save className="w-4 h-4 ml-1" /> {saving ? 'جاري الحفظ...' : 'حفظ'}
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>إلغاء</Button>
        </div>
      </div>
    </form>
  )
}

// ==================== CATEGORIES MANAGER ====================
function CategoriesManager({ onRefresh }: { onRefresh: () => void }) {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [newCatName, setNewCatName] = useState('')
  const [newCatIcon, setNewCatIcon] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editName, setEditName] = useState('')
  const [editIcon, setEditIcon] = useState('')

  const fetchCategories = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/categories')
      const data = await res.json()
      setCategories(Array.isArray(data) ? data : [])
    } catch { toast.error('خطأ في تحميل التصنيفات') }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchCategories() }, [])

  const handleAdd = async () => {
    if (!newCatName.trim()) { toast.error('أدخل اسم التصنيف'); return }
    try {
      await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newCatName, icon: newCatIcon || '📦' }),
      })
      toast.success('تم إضافة التصنيف')
      setNewCatName(''); setNewCatIcon('')
      fetchCategories(); onRefresh()
    } catch { toast.error('خطأ في إضافة التصنيف') }
  }

  const handleUpdate = async (id: string) => {
    try {
      await fetch('/api/categories', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, name: editName, icon: editIcon }),
      })
      toast.success('تم تحديث التصنيف')
      setEditingId(null)
      fetchCategories(); onRefresh()
    } catch { toast.error('خطأ في تحديث التصنيف') }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد؟ سيتم حذف جميع منتجات هذا التصنيف!')) return
    try {
      await fetch('/api/categories?id=' + id, { method: 'DELETE' })
      toast.success('تم حذف التصنيف')
      fetchCategories(); onRefresh()
    } catch { toast.error('خطأ في حذف التصنيف') }
  }

  return (
    <Card>
      <CardContent className="p-4 md:p-6">
        <h3 className="text-lg font-bold flex items-center gap-2 mb-6">
          <Tag className="w-5 h-5 text-emerald-600" /> التصنيفات ({categories.length})
        </h3>

        {/* Add new category */}
        <div className="flex gap-2 mb-6">
          <Input value={newCatIcon} onChange={(e) => setNewCatIcon(e.target.value)}
            placeholder="أيقونة (إيموجي)" className="w-24 text-center text-xl" />
          <Input value={newCatName} onChange={(e) => setNewCatName(e.target.value)}
            placeholder="اسم التصنيف الجديد" className="flex-1"
            onKeyDown={(e) => e.key === 'Enter' && handleAdd()} />
          <Button onClick={handleAdd} className="bg-emerald-600 hover:bg-emerald-700 gap-1">
            <Plus className="w-4 h-4" /> إضافة
          </Button>
        </div>

        {/* Categories list */}
        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-14 bg-muted rounded-lg animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {categories.map((cat, i) => (
              <div key={cat.id} className={`flex items-center gap-3 p-3 rounded-xl border transition-colors ${
                editingId === cat.id ? 'border-amber-300 bg-amber-50' : 'border-border hover:bg-emerald-50/50'
              }`}>
                <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center text-xl shrink-0">
                  {editingId === cat.id ? editIcon : cat.icon}
                </div>
                {editingId === cat.id ? (
                  <div className="flex-1 flex gap-2">
                    <Input value={editIcon} onChange={(e) => setEditIcon(e.target.value)} className="w-20 text-center text-lg" />
                    <Input value={editName} onChange={(e) => setEditName(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleUpdate(cat.id)} className="flex-1" />
                  </div>
                ) : (
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{cat.name}</p>
                    <p className="text-xs text-muted-foreground">{cat._count.products} منتج</p>
                  </div>
                )}
                <div className="flex items-center gap-1 shrink-0">
                  {editingId === cat.id ? (
                    <>
                      <Button size="sm" className="h-8 bg-emerald-600 hover:bg-emerald-700"
                        onClick={() => handleUpdate(cat.id)}>
                        <Save className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-8"
                        onClick={() => setEditingId(null)}>
                        <X className="w-4 h-4" />
                      </Button>
                    </>
                  ) : (
                    <>
                      <Button size="icon" variant="ghost" className="h-8 w-8"
                        onClick={() => { setEditingId(cat.id); setEditName(cat.name); setEditIcon(cat.icon || '') }}>
                        <Pencil className="w-4 h-4 text-emerald-600" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8"
                        onClick={() => handleDelete(cat.id)}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// ==================== STORE SETTINGS MANAGER ====================
function StoreSettingsManager() {
  const [settings, setSettings] = useState({
    storeName: '', phone: '', address: '', whatsapp: '', facebook: ''
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(data => {
      setSettings({
        storeName: data.storeName || '',
        phone: data.phone || '',
        address: data.address || '',
        whatsapp: data.whatsapp || '',
        facebook: data.facebook || '',
      })
    }).catch(() => {}).finally(() => setLoading(false))
  }, [])

  const handleSave = async () => {
    setSaving(true)
    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      toast.success('تم حفظ الإعدادات')
    } catch { toast.error('خطأ في حفظ الإعدادات') }
    finally { setSaving(false) }
  }

  if (loading) return <Card><CardContent className="p-8 text-center text-muted-foreground">جاري التحميل...</CardContent></Card>

  return (
    <Card>
      <CardContent className="p-4 md:p-6">
        <h3 className="text-lg font-bold flex items-center gap-2 mb-6">
          <Store className="w-5 h-5 text-emerald-600" /> إعدادات المتجر
        </h3>
        <div className="space-y-4 max-w-lg">
          <div>
            <Label>اسم المتجر</Label>
            <Input value={settings.storeName} onChange={(e) => setSettings({ ...settings, storeName: e.target.value })}
              className="mt-1" />
          </div>
          <div>
            <Label>رقم الهاتف</Label>
            <Input value={settings.phone} onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
              placeholder="01012345678" className="mt-1" dir="ltr" />
          </div>
          <div>
            <Label>العنوان</Label>
            <Input value={settings.address} onChange={(e) => setSettings({ ...settings, address: e.target.value })}
              className="mt-1" />
          </div>
          <div>
            <Label>رقم الواتساب (بدون +)</Label>
            <Input value={settings.whatsapp} onChange={(e) => setSettings({ ...settings, whatsapp: e.target.value })}
              placeholder="201012345678" className="mt-1" dir="ltr" />
          </div>
          <div>
            <Label>رابط صفحة فيسبوك</Label>
            <Input value={settings.facebook} onChange={(e) => setSettings({ ...settings, facebook: e.target.value })}
              placeholder="pagename" className="mt-1" dir="ltr" />
          </div>
          <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700" disabled={saving}>
            <Save className="w-4 h-4 ml-1" /> {saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}