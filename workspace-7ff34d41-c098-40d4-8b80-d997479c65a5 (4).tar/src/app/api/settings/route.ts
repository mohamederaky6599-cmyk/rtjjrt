import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  try {
    let settings = await db.storeSettings.findFirst()
    if (!settings) {
      settings = await db.storeSettings.create({
        data: {
          storeName: 'مكه استور',
          phone: '01012345678',
          address: 'بنها - مينة السباع - القليوبية',
        },
      })
    }
    return NextResponse.json(settings)
  } catch (error) {
    console.error('GET settings error:', error)
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    let settings = await db.storeSettings.findFirst()
    if (!settings) {
      settings = await db.storeSettings.create({ data: body })
    } else {
      settings = await db.storeSettings.update({
        where: { id: settings.id },
        data: body,
      })
    }
    return NextResponse.json(settings)
  } catch (error) {
    console.error('PUT settings error:', error)
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 })
  }
}
