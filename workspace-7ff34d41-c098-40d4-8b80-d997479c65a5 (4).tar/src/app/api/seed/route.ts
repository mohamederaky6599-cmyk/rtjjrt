import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function POST() {
  try {
    // Create categories
    const categories = await Promise.all([
      db.category.upsert({
        where: { id: 'cat-pens' },
        update: {},
        create: { id: 'cat-pens', name: 'أدوات كتابية', nameEn: 'Writing Tools', icon: '✏️', order: 1 },
      }),
      db.category.upsert({
        where: { id: 'cat-notebooks' },
        update: {},
        create: { id: 'cat-notebooks', name: 'دفاتر وكراسات', nameEn: 'Notebooks', icon: '📓', order: 2 },
      }),
      db.category.upsert({
        where: { id: 'cat-bags' },
        update: {},
        create: { id: 'cat-bags', name: 'حقائب مدرسية', nameEn: 'School Bags', icon: '🎒', order: 3 },
      }),
      db.category.upsert({
        where: { id: 'cat-geometry' },
        update: {},
        create: { id: 'cat-geometry', name: 'أدوات هندسية', nameEn: 'Geometry Tools', icon: '📐', order: 4 },
      }),
      db.category.upsert({
        where: { id: 'cat-colors' },
        update: {},
        create: { id: 'cat-colors', name: 'ألوان وفنون', nameEn: 'Art Supplies', icon: '🎨', order: 5 },
      }),
      db.category.upsert({
        where: { id: 'cat-office' },
        update: {},
        create: { id: 'cat-office', name: 'أدوات مكتبية', nameEn: 'Office Supplies', icon: '📎', order: 6 },
      }),
      db.category.upsert({
        where: { id: 'cat-calculators' },
        update: {},
        create: { id: 'cat-calculators', name: 'آلات حاسبة', nameEn: 'Calculators', icon: '🔢', order: 7 },
      }),
      db.category.upsert({
        where: { id: 'cat-sets' },
        update: {},
        create: { id: 'cat-sets', name: 'باقات وأطقم', nameEn: 'Sets & Bundles', icon: '🎁', order: 8 },
      }),
    ])

    // Create products for each category
    const products = [
      // أدوات كتابية
      { name: 'قلم حبر جاف ستيدلر تريبلوكس', categoryId: 'cat-pens', price: 45, oldPrice: 55, description: 'قلم ستيدلر تريبلوكس - أزرق - ناعم الكتابة', featured: true, order: 1 },
      { name: 'قلم رصاص HB ستيدلر مارس لومو', categoryId: 'cat-pens', price: 15, description: 'قلم رصاص ستيدلر مارس لومو - درجة HB - مثالي للكتابة والرسم', order: 2 },
      { name: 'قلم حبر أبيض كوريكيتا إراسر', categoryId: 'cat-pens', price: 60, description: 'قلم حبر أبيض للتصحيح - كوريكيتا إراسر', order: 3 },
      { name: 'ممحاة ستيدلر بلاستيك', categoryId: 'cat-pens', price: 10, description: 'ممحاة بلاستيكية عالية الجودة', order: 4 },
      { name: 'أقلام ملونة فيبرو 12 لون', categoryId: 'cat-pens', price: 85, oldPrice: 100, description: 'طقم أقلام فيبرو 12 لون - جودة عالية', featured: true, order: 5 },
      { name: 'قلم حبر جاف بيلوت G2', categoryId: 'cat-pens', price: 35, description: 'قلم بيلوت G2 - أسود - متين ومريح', order: 6 },
      { name: 'قلم حبر جاف فابر كاستيل جريب', categoryId: 'cat-pens', price: 30, description: 'قلم فابر كاستيل جريب - متعدد الألوان', order: 7 },
      { name: 'برايز ميكانيكي 0.5', categoryId: 'cat-pens', price: 25, description: 'برايز ميكانيكي 0.5mm مع رصاص إضافي', order: 8 },

      // دفاتر وكراسات
      { name: 'دفتر سطر 80 ورق سمارت', categoryId: 'cat-notebooks', price: 20, description: 'دفتر 80 ورق - سطر - غلاف سمارت مقوى', order: 1 },
      { name: 'دفتر سطر 40 ورق سمارت', categoryId: 'cat-notebooks', price: 12, description: 'دفتر 40 ورق - سطر - غلاف مقوى', order: 2 },
      { name: 'دفتر شبك 80 ورق سمارت', categoryId: 'cat-notebooks', price: 20, description: 'دفتر 80 ورق - شبك - غلاف سمارت مقوى', order: 3 },
      { name: 'دفتر رسم A3 40 ورق', categoryId: 'cat-notebooks', price: 35, oldPrice: 45, description: 'دفتر رسم كبير A3 - 40 ورق - ورق سميك', featured: true, order: 4 },
      { name: 'كراسة خط عربي', categoryId: 'cat-notebooks', price: 18, description: 'كراسة تعليم الخط العربي - 40 ورق', order: 5 },
      { name: 'دفتر فوتوكوبي A4 100 ورق', categoryId: 'cat-notebooks', price: 55, description: 'دفتر فوتوكوبي A4 - 100 ورق - للطباعة', order: 6 },

      // حقائب مدرسية
      { name: 'حقيبة ظهر مدرسية - وردية', categoryId: 'cat-bags', price: 350, oldPrice: 450, description: 'حقيبة ظهر للبنات - وردية - مقاومة للماء - جيوب متعددة', featured: true, order: 1 },
      { name: 'حقيبة ظهر مدرسية - زرقاء', categoryId: 'cat-bags', price: 350, oldPrice: 450, description: 'حقيبة ظهر للأولاد - زرقاء - مقاومة للماء', order: 2 },
      { name: 'حقيبة كتف مدرسية صغيرة', categoryId: 'cat-bags', price: 180, description: 'حقيبة كتف خفيفة - مناسبة للمرحلة الابتدائية', order: 3 },
      { name: 'شنطة أدوات مدرسية', categoryId: 'cat-bags', price: 80, description: 'شنطة أدوات مدرسية - محفظة أدوات - ألوان متعددة', order: 4 },
      { name: 'حقيبة ظهر رياضية', categoryId: 'cat-bags', price: 280, description: 'حقيبة رياضية خفيفة - حزام صدر', order: 5 },

      // أدوات هندسية
      { name: 'مسطرة 30 سم شفافة', categoryId: 'cat-geometry', price: 10, description: 'مسطرة بلاستيكية شفافة 30 سم', order: 1 },
      { name: 'منقلة شفافة 180 درجة', categoryId: 'cat-geometry', price: 10, description: 'منقلة بلاستيكية شفافة - مقاسات واضحة', order: 2 },
      { name: 'فرجار معدني', categoryId: 'cat-geometry', price: 25, description: 'فرجار معدني دقيق - للرسم الهندسي', order: 3 },
      { name: 'طقم أدوات هندسية 8 قطع', categoryId: 'cat-geometry', price: 55, oldPrice: 70, description: 'طقم أدوات هندسية متكامل - 8 قطع - محفظة بلاستيكية', featured: true, order: 4 },
      { name: 'مسطرة مثلثة 60 درجة', categoryId: 'cat-geometry', price: 8, description: 'مسطرة مثلثة بلاستيكية - 60 و 30 درجة', order: 5 },
      { name: 'منقلة دائرية 360 درجة', categoryId: 'cat-geometry', price: 15, description: 'منقلة دائرية كاملة - للرسم الدائري', order: 6 },

      // ألوان وفنون
      { name: 'ألوان خشبية 12 لون فابر كاستيل', categoryId: 'cat-colors', price: 65, oldPrice: 80, description: 'ألوان خشبية فابر كاستيل - 12 لون - جودة فنية', featured: true, order: 1 },
      { name: 'ألوان خشبية 24 لون فابر كاستيل', categoryId: 'cat-colors', price: 120, oldPrice: 150, description: 'ألوان خشبية فابر كاستيل - 24 لون', order: 2 },
      { name: 'ألوان مائية 12 لون', categoryId: 'cat-colors', price: 45, description: 'طقم ألوان مائية 12 لون مع فرشاة', order: 3 },
      { name: 'ألوان شمع 12 لون', categoryId: 'cat-colors', price: 20, description: 'ألوان شمع ناعمة - 12 لون - للرسومات', order: 4 },
      { name: 'ألوان بلاستيك 24 لون', categoryId: 'cat-colors', price: 50, description: 'ألوان بلاستيك 24 لون - طويلة الأمد', order: 5 },
      { name: 'طقم فرش رسم 6 قطع', categoryId: 'cat-colors', price: 40, description: 'طقم فرش رسم متنوعة - 6 أحجام مختلفة', order: 6 },
      { name: 'بالاتين ألوان خشبية 48 لون', categoryId: 'cat-colors', price: 220, oldPrice: 280, description: 'ألوان خشبية 48 لون - بالاتين - للفنانين المحترفين', order: 7 },

      // أدوات مكتبية
      { name: 'مقص مدارس ستيدلر', categoryId: 'cat-office', price: 30, description: 'مقص آمن للأطفال - ستيدلر - مقبض مريح', order: 1 },
      { name: 'لاصق شفاف 12 مم', categoryId: 'cat-office', price: 8, description: 'لاصق شفاف 12 مم - للترميم واللصق', order: 2 },
      { name: 'دباسة معدنية 24/6', categoryId: 'cat-office', price: 25, description: 'دباسة قوية - مقاس 24/6', order: 3 },
      { name: 'فك دباسة معدني', categoryId: 'cat-office', price: 15, description: 'فك دباسة معدني - متين', order: 4 },
      { name: 'ملف بلاستيك A4', categoryId: 'cat-office', price: 12, description: 'ملف بلاستيك شفاف - مقاس A4', order: 5 },
      { name: 'صندوق أدوات مدرسية كبير', categoryId: 'cat-office', price: 45, oldPrice: 55, description: 'علبة أدوات مدرسية كبيرة - جيوب متعددة', featured: true, order: 6 },
      { name: 'غراء لاصق 40 جم', categoryId: 'cat-office', price: 10, description: 'غراء لاصق - 40 جم - آمن للأطفال', order: 7 },

      // آلات حاسبة
      { name: 'آلة حاسبة علمية كاسيو fx-991EX', categoryId: 'cat-calculators', price: 550, oldPrice: 650, description: 'آلة حاسبة علمية كاسيو - FX-991EX - للمرحلة الثانوية والجامعية', featured: true, order: 1 },
      { name: 'آلة حاسبة كاسيو fx-82ES', categoryId: 'cat-calculators', price: 250, oldPrice: 300, description: 'آلة حاسبة علمية كاسيو - FX-82ES - للمرحلة الإعدادية والثانوية', order: 2 },
      { name: 'آلة حاسبة عادية كاسيو HS-8VA', categoryId: 'cat-calculators', price: 120, description: 'آلة حاسبة عادية - 8 أرقام - للمرحلة الابتدائية', order: 3 },
      { name: 'آلة حاسبة مكتبية 12 رقم', categoryId: 'cat-calculators', price: 80, description: 'آلة حاسبة مكتبية - 12 رقم - كبيرة ومريحة', order: 4 },

      // باقات وأطقم
      { name: 'باقة الابتدائي الكاملة', categoryId: 'cat-sets', price: 450, oldPrice: 600, description: 'باقة شاملة للمرحلة الابتدائية: دفاتر + أقلام + أدوات هندسية + ألوان + محفظة', featured: true, order: 1 },
      { name: 'باقة الإعدادي الكاملة', categoryId: 'cat-sets', price: 650, oldPrice: 800, description: 'باقة شاملة للمرحلة الإعدادية: دفاتر + أقلام + أدوات هندسية + آلة حاسبة', featured: true, order: 2 },
      { name: 'باقة الثانوي الكاملة', categoryId: 'cat-sets', price: 900, oldPrice: 1100, description: 'باقة شاملة للمرحلة الثانوية: كل الأدوات المطلوبة + آلة حاسبة علمية', featured: true, order: 3 },
      { name: 'طقم رسم فني كامل', categoryId: 'cat-sets', price: 200, oldPrice: 260, description: 'طقم رسم فني: ألوان خشبية + فرش + دفتر رسم + ممحاة', order: 4 },
      { name: 'طقم مكتب متكامل', categoryId: 'cat-sets', price: 120, oldPrice: 150, description: 'طقم مكتب: دباسة + فك + مقص + لاصق + ملفات', order: 5 },
    ]

    for (const product of products) {
      await db.product.upsert({
        where: { id: `prod-${product.order}-${product.categoryId}` },
        update: { name: product.name, price: product.price, oldPrice: product.oldPrice ?? null, description: product.description, featured: product.featured, order: product.order },
        create: { id: `prod-${product.order}-${product.categoryId}`, ...product, oldPrice: product.oldPrice ?? null },
      })
    }

    // Create store settings
    await db.storeSettings.upsert({
      where: { id: 'settings-1' },
      update: {},
      create: {
        id: 'settings-1',
        storeName: 'مكه استور',
        phone: '01012345678',
        address: 'بنها - مينة السباع - القليوبية',
        whatsapp: '201012345678',
        facebook: 'makastore',
      },
    })

    return NextResponse.json({ success: true, categoriesCount: categories.length, productsCount: products.length })
  } catch (error) {
    console.error('Seed error:', error)
    return NextResponse.json({ error: 'Failed to seed database' }, { status: 500 })
  }
}
