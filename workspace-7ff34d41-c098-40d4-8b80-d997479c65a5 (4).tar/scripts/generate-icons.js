const sharp = require('sharp');
const path = require('path');

async function generateIcons() {
  const svgIcon = `
  <svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#059669"/>
        <stop offset="100%" style="stop-color:#064e3b"/>
      </linearGradient>
    </defs>
    <rect width="512" height="512" rx="96" fill="url(#bg)"/>
    <text x="256" y="200" text-anchor="middle" font-family="Arial, sans-serif" font-size="120" font-weight="bold" fill="white">مكه</text>
    <text x="256" y="320" text-anchor="middle" font-family="Arial, sans-serif" font-size="80" font-weight="bold" fill="#fbbf24">استور</text>
    <text x="256" y="420" text-anchor="middle" font-family="Arial, sans-serif" font-size="36" fill="#a7f3d0">أدوات مدرسية</text>
  </svg>
  `;

  const sizes = [192, 512];
  for (const size of sizes) {
    await sharp(Buffer.from(svgIcon))
      .resize(size, size)
      .png()
      .toFile(path.join(__dirname, '..', 'public', `icon-${size}x${size}.png`));
    console.log(`Generated icon-${size}x${size}.png`);
  }

  // Apple touch icon (180x180)
  await sharp(Buffer.from(svgIcon))
    .resize(180, 180)
    .png()
    .toFile(path.join(__dirname, '..', 'public', 'apple-touch-icon.png'));
  console.log('Generated apple-touch-icon.png');

  // Small favicon (32x32)
  await sharp(Buffer.from(svgIcon))
    .resize(32, 32)
    .png()
    .toFile(path.join(__dirname, '..', 'public', 'favicon-32x32.png'));
  console.log('Generated favicon-32x32.png');
}

generateIcons().catch(console.error);
